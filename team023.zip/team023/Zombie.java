package team023;

import battlecode.common.*;
import java.util.*;

public class Zombie extends RobotPlayer
{
}
